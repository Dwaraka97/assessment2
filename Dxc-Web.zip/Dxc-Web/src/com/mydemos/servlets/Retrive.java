package com.mydemos.servlets;

import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.jdbc.dao.RetriveDao;

@WebServlet("/Retrive")
public class Retrive extends HttpServlet {
       @Override
       protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	   PrintWriter out= response.getWriter();
    	   RetriveDao display=new RetriveDao();
    	   String[] b=display.displayData();
    	   String[] data=new String[5];
    	   out.print("<h1>Employee Details<br>");
    	   for(int i=0;i<b.length;i++)
    	   {
    			  data=b[i].split(",",5);
    			  out.print("<h1>"+data[0]+"  "+data[1]+"  "+data[2]+"  "+data[3]+"  "+data[4]);
    	   }
    	   
    	   
    	   }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
