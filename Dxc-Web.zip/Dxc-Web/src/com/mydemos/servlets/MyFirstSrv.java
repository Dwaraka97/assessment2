package com.mydemos.servlets;
import java.util.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.jdbc.dao.*;
import com.jdbc.pojo.Employee;

@WebServlet("/MyFirstSrv")
public class MyFirstSrv extends HttpServlet {

	@Override
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out= response.getWriter();
		
		String employeeName=request.getParameter("name");
		String lastName=request.getParameter("lastName");
		String employeeAddress=request.getParameter("address");
		String employeeDob=request.getParameter("empDob");
		
		
	
		EmployeeDao dao=new EmployeeDao();
		Employee emp=new Employee();
		SequenceDao sequence=new SequenceDao();
		
		
		String seq=sequence.sequenceGen();
		
	String empid=employeeName.substring(0, 2)+lastName.substring(0, 2)+seq;
		
		
		emp.setName(employeeName);
		emp.setLastName(lastName);
		emp.setEmpId(empid);
		emp.setAddress(employeeAddress);
		
		
		SimpleDateFormat sd=new SimpleDateFormat("yyyy-MM-dd");
		Date dob;
			try {
				dob = sd.parse(employeeDob);
				emp.setEmpDob(dob);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
		String a=dao.saveEmployee(emp);
		if(a=="failed")
			out.print("<h1>Failed to Update Employee Details");
		else
			out.print("<h1>Employee Details Updated Successfully");
		
		
	}		
}
