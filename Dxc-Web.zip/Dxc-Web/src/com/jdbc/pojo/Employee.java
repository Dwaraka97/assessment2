package com.jdbc.pojo;
import java.util.Date;
public class Employee {

	private String name;
	private String lastName;
	private String empId;
	private String address;
	private Date empDob;
	
	public Date getEmpDob() {
		return empDob;
	}
	public void setEmpDob(Date empDob) {
		this.empDob = empDob;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Employee(){}
	public Employee(String name,String lastName,String empId,String address,Date empDob) {
		this.name = name;
		this.lastName = lastName;
		this.empId = empId;
		this.address = address;
		this.empDob=empDob;
	}
	@Override
	public String toString() {

	return getName()+" "+getLastName()+" "+getEmpId()+" "+getAddress()+" "+getEmpDob();
	}
	
}
