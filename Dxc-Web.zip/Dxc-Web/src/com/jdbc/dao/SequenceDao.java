package com.jdbc.dao;

import java.sql.*;

import com.jdbc.dbutil.DbConn;

public class SequenceDao {

	/**
	 * @return
	 */
	public String sequenceGen()
	{
		try
		{
		Connection con=DbConn.getConnection();
		String sql="select to_char(seqnum.nextval,'FM009') from dual";
		PreparedStatement smt=con.prepareStatement(sql);
		ResultSet rs=smt.executeQuery();
		rs.next();
		//System.out.println(rs.getInt(1));
		int seq= rs.getInt(1);
		String a=Integer.toString(seq);
		String b="";
		if(a.length()==1)
			b="00"+a;
		else if(a.length()==2)
			b="0"+a;
		else
			b=a;
		if(seq>0)
			return b;
		}
		catch (Exception e) {
		e.printStackTrace();
		}
		return "Sequence number not found";
	}
}
