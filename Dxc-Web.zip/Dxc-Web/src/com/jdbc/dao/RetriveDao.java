package com.jdbc.dao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;

import com.jdbc.dbutil.DbConn;


public class RetriveDao {

	public String[] displayData()
	{
		try
		{
			Connection con=DbConn.getConnection();
			String sql="select * from employee";
			PreparedStatement smt=con.prepareStatement(sql);
			ResultSet res=smt.executeQuery();
			
		String[] data=new String[20];
		int i=0;
		while(res.next())
		{		
		//System.out.println(res.getString(1)+" "+res.getString(2)+" "+res.getString(3)+" "+res.getString(4)+" "+res.getDate(5));
		String name=res.getString(1);
		String lastname=res.getString(2);
		String empId=res.getString(3);
		String address=res.getString(4);
		String date=res.getDate(5).toString();
		data[i]=name+","+lastname+","+empId+","+address+","+date;
		i++;
		}
		return data;
		}
		catch (Exception e) {
		e.printStackTrace();
		}
		String[] a=new String[3];
		return a;
	}
	
}
