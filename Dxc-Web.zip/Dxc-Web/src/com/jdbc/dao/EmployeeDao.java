package com.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Date;




import com.jdbc.dbutil.DbConn;
import com.jdbc.pojo.Employee;

public class EmployeeDao {

public  String saveEmployee(Employee employee)
{
try
{
Connection con=DbConn.getConnection();

String sql="insert into employee values(?,?,?,?,?)";

PreparedStatement stat=con.prepareStatement(sql);


stat.setString(1, employee.getName());
stat.setString(2, employee.getLastName());
stat.setString(3, employee.getEmpId());
stat.setString(4, employee.getAddress());
java.util.Date dob=employee.getEmpDob();

Date sqlDate=new Date(dob.getYear(), dob.getMonth(), dob.getDate());


stat.setDate(5, sqlDate);


int res= stat.executeUpdate();
if(res>0)
return "Employee details saved";


}
catch (Exception e) {
e.printStackTrace();
}

return "failed";

}
}