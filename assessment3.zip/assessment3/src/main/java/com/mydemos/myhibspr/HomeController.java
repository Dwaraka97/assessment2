package com.mydemos.myhibspr;

import java.util.ArrayList;
//import java.text.DateFormat;
//import java.util.Date;
import java.util.Locale;

/*import org.slf4j.Logger;
import org.slf4j.LoggerFactory;*/
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mydemos.model.Restaurant;
import com.mydemos.dao.RestaurantDao;
//@Transactional
@Controller
public class HomeController {
	
	
	@Autowired
	RestaurantDao restaurantDao;
	
	@RequestMapping(value = "/")
	public String home(Locale locale, Model model) {
		return "home";
	}
	
	@RequestMapping(value = "/saveRest")
	public String saveRest(@ModelAttribute Restaurant restaurant) {
		restaurantDao.saveResturant(restaurant);
		return "success";
	}
		@RequestMapping(value="/displaybyloc")
		public String displaybyloc()
		{
			return "displaybyloc";
		}
	  @RequestMapping(value = "/display") 
	  public String display (@RequestParam("location") String location,Model model) {
		  ArrayList<Restaurant> ls=restaurantDao.displayByLoc(location); 
		  model.addAttribute("lists", ls); 
		  return "diplayByLoc"; 
		  }
	 
	  @RequestMapping(value = "/deleteRest")
		public String deletepage(Locale locale, Model model) {
			return "delete";
		}
	  @RequestMapping(value = "/delete")
		public String deleteRest(@RequestParam String name) {
		  restaurantDao.deleteResturant(name);
			return "success";
		}
	  @RequestMapping(value = "/disp") 
	  public String search(Model model, @ModelAttribute Restaurant resturants)
	{
	  ArrayList<Restaurant> restList =  restaurantDao.getRestaurants();
	  model.addAttribute("restaurants",restList); 
	  System.out.println(restList);
	  return "display"; 
	  } 
	  @RequestMapping(value = "/updateRest")
		public String updatepage(Locale locale, Model model) {
			return "update";
		}
		
		@RequestMapping(value = "/update")
		public String updateRest(@ModelAttribute Restaurant restaurant) {
			restaurantDao.updateRestaurant(restaurant);
			return "success";
		} 
		@RequestMapping(value="/home")
		public String home()
		{
			return "home";
		}
	
}


