package com.mydemos.dao;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mydemos.model.Restaurant;


@Transactional
@Component
public class RestaurantDao {

	@Autowired
	SessionFactory sessionFactory;
	
	
	public void saveResturant(Restaurant restaurant){	
	Session session=sessionFactory.getCurrentSession();
	session.save(restaurant);
	}

	
	public ArrayList<Restaurant> displayByLoc(String loc)
	{
		Session session= sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Restaurant  where location=:location");
		query.setParameter("location", loc);
		ArrayList<Restaurant> ls=(ArrayList<Restaurant>)query.list();
		return ls;	
	}
	
	@Transactional
	public String deleteResturant(String name){	
	Session session=	sessionFactory.getCurrentSession();
	//Resturant resturant=getResturant(name);
	Restaurant resturant=(Restaurant) session.get(Restaurant.class, name);
	session.delete(resturant);
	return "Resturant Deleted";
	}
	
	@Transactional
	public  ArrayList<Restaurant> getRestaurants()
	{
	Session session=sessionFactory.getCurrentSession();
	ArrayList<Restaurant> restaurants=(ArrayList<Restaurant>)session.createQuery("from Restaurant").list();	
//	System.out.println(resturants);
	return restaurants;
	
	}
	@Transactional
	public void updateRestaurant(Restaurant restaurant){	
	Session session=	sessionFactory.getCurrentSession();
	session.update(restaurant);
	}
}
