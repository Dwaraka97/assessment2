package com.jdbc.pojo;

public class Employee {

	private String name;
	private String lastName;
	private String empId;
	private String address;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Employee(){}
	public Employee(String name,String lastName,String empId,String address) {
		this.name = name;
		this.lastName = lastName;
		this.empId = empId;
		this.address = address;
	}
	
}
