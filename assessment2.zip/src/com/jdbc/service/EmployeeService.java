package com.jdbc.service;
import java.util.*;


import com.jdbc.dao.EmployeeDao;
import com.jdbc.dao.SequenceDao;
import com.jdbc.pojo.Employee;



public class EmployeeService {

public static void main(String[] args) {

EmployeeDao dao=new EmployeeDao();
Employee employee=new Employee();
SequenceDao sequence=new SequenceDao();
String name,lastName,address;



String seq=sequence.sequenceGen();

//System.out.println(seq);


@SuppressWarnings("resource")
Scanner sc=new Scanner(System.in);
System.out.println("Enter name of employee");
name=sc.nextLine();
System.out.println("Enter Last name of employee");
lastName=sc.nextLine();
System.out.println("Enter address of employee");
address=sc.nextLine();

StringBuilder empId=new StringBuilder();
empId.setLength(0);

empId.append(name.charAt(0));
empId.append(name.charAt(1));
empId.append(lastName.charAt(0));
empId.append(lastName.charAt(1));
empId.append(seq);

String id=empId.toString();
employee.setName(name);
employee.setLastName(lastName);
employee.setEmpId(id);
employee.setAddress(address);


System.out.println(dao.saveEmployee(employee));




}

}